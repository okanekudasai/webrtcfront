package rtc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebrtcgoApplicationTests {

	@Test
	void contextLoads() {
	}

}
